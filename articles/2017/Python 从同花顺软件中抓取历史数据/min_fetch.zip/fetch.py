import sys,time,datetime,os,winsound,hexin

def get_previous_date(date):
	date=datetime.datetime.strptime(date,'%Y-%m-%d')
	date-=datetime.timedelta(days=1)
	return date.strftime('%Y-%m-%d')

output_dir='D:/szzs_min_k_p'

if len(sys.argv)==1:
	files=os.listdir(output_dir)
	if len(files)>0:
		files.sort()
		date=get_previous_date(os.path.splitext(os.path.split(files[0])[1])[0])
	else:
		date=datetime.datetime.now().strftime('%Y-%m-%d')
else:
	date=sys.argv[1]
	try:
		datetime.datetime.strptime(date,'%Y-%m-%d')
	except ValueError:
		raise IOError('<date> must in format of YYYY-mm-dd')

fetch=hexin.HexinFetch((10,35,55,55),((0,70,70,85),(0,130,70,145)))

while True:
	try:
		print(date)
		result=fetch.fetch_day(date,False)
		if result!=None:
			date,table=result
			file=open('%s/%s.txt' % (output_dir,date),'w')
			for row in table:
				file.write('\t'.join(row)+'\n')
			file.close()
			date=get_previous_date(date)
		else:
			raise IOError('Wrong date %s' % date)
	except KeyboardInterrupt:
		break
	except:
		winsound.Beep(1000,1000)