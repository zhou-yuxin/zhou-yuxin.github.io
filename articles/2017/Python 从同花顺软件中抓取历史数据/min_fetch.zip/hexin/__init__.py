import os,time,re
import win32api,win32gui,win32con
from PIL import Image,ImageFile,ImageGrab

class HexinFetch:

	def __init__(self,bbox_min,bbox_vals):
		kwin_lst=self.__find_wins_by_title('^同花顺\(v\\d+\\.\\d+\\.\\d+\\)')
		if len(kwin_lst)==0:
			raise IOError('No K line window found')
		elif len(kwin_lst)>1:
			raise IOError('More than one K line window found: '+str(kwin_lst))
		self.__kwin=kwin_lst[0][0]
		twin_lst=self.__find_wins_by_title('.+\(\\d{6}\) \\d{4}-\\d{2}-\\d{2}')
		if len(twin_lst)==0:
			raise IOError('No tick window found')
		elif len(twin_lst)>1:
			raise IOError('More than one tick window found: '+str(twin_lst))
		self.__twin=twin_lst[0][0]
		kpanel=self.__get_child_by_ids(self.__kwin,[0xE900])
		if kpanel==0:
			raise IOError('Cannot get k line panel')
		tpanel=self.__get_child_by_ids(self.__twin,[0xE801,0])
		if tpanel==0:
			raise IOError('Cannot get tick panel')
		(left,top,right,bottom)=win32gui.GetWindowRect(tpanel)
		self.__bbox_load=(left+35,top+15,left+65,top+30)
		self.__bbox_ready=(left,top+15,left+15,top+30)
		if not isinstance(bbox_min,(tuple,list)) or len(bbox_min)!=4:
			raise TypeError('Param <bbox_min> is not a 4-tuple or 4-list')
		self.__bbox_min=(left+bbox_min[0],top+bbox_min[1],left+bbox_min[2],top+bbox_min[3])
		if not isinstance(bbox_vals,(tuple,list)):
			raise TypeError('Param <bbox_vals> is not a tuple or list')
		self.__bbox_vals=[]
		for bbox_val in bbox_vals:
			if not isinstance(bbox_val,(tuple,list)) or len(bbox_val)!=4:
				raise TypeError('Param <bbox_vals> is not a tuple of 4-tuple or 4-list')
			self.__bbox_vals.append((left+bbox_val[0],top+bbox_val[1],left+bbox_val[2],top+bbox_val[3]))
		self.__ocr=HexinOCR()

	def fetch_day(self,date_lim,half=False):
		date,last_date=None,None
		while True:
			date=self.__get_date()
			if date<=date_lim:
				break
			self.__press_key(self.__kwin,'left',0.2,0.5)
			date=self.__get_date()
			if date==last_date:
				time.sleep(5)
			last_date=date
		while self.__is_bbox_empty(self.__bbox_load):
			time.sleep(1)
		while True:
			self.__press_key(self.__twin,'right',0.5,0.5)
			if not self.__is_bbox_empty(self.__bbox_ready):
				break
			time.sleep(1)
		morning=['%02d:%02d' % (int((m+30)/60)+9,(m+30)%60) for m in range(2*60)]
		afternoon=['%02d:%02d' % (int((m+1)/60)+13,(m+1)%60) for m in range(2*60)]
		minutes=(*morning,'11:30') if half else (*morning,'11:30',*afternoon)
		table=[]
		for m in minutes:
			while True:
				minute=self.__recognize_grab(ImageGrab.grab(self.__bbox_min))
				if minute<m:
					self.__press_key(self.__twin,'right',0,0.3)
				elif minute>m:
		 			self.__press_key(self.__twin,'left',0,0.1)
				else:
					grabs=[ImageGrab.grab(bbox) for bbox in self.__bbox_vals]
					self.__press_key(self.__twin,'right',0,0.05)
					values=[self.__recognize_grab(grab) for grab in grabs]
					checks=[float(v) for v in values]
					break
			if self.__get_date()!=date:
	 			return None
			row=(minute,*values)
			print(row)
			table.append(row)
		return date,table

	def __find_wins_by_title(self,tregx):
		hwnd_lst=[]
		regx=re.compile(tregx)
		def on_enum_window(hwnd,extra):
			title=win32gui.GetWindowText(hwnd)
			if regx.match(title):
				hwnd_lst.append((hwnd,title))
		win32gui.EnumWindows(on_enum_window,0)
		return hwnd_lst

	def __get_child_by_ids(self,hwnd,path):
		for id in path:
			hwnd=win32gui.GetDlgItem(hwnd,id)
		return hwnd

	def __press_key(self,win,key,delay_before,delay_after):
		win32gui.SetForegroundWindow(win)
		time.sleep(delay_before)
		m={'left':37,'right':39}
		key=m.get(key)
		win32api.keybd_event(key,0,0,0)
		win32api.keybd_event(key,0,win32con.KEYEVENTF_KEYUP,0)
		time.sleep(delay_after)

	def __get_date(self):
		title=win32gui.GetWindowText(self.__twin)
		regx=re.compile(' (\\d{4}-\\d{2}-\\d{2}) ')
		date=regx.findall(title)
		if len(date)!=1:
			raise IOError('Wrong date '+str(date))
		return date[0]

	def __is_bbox_empty(self,bbox):
		im=ImageGrab.grab(bbox)
		raw=im.getdata()
		for p in raw:
			if p[0:3]!=(0,0,0):
				return False
		return True

	def __recognize_grab(self,im):
		text=self.__ocr.recognize(im)
		if len(text)!=1:
			raise IOError('Count is not 1, bbox may be wrong')
		return text[0]

class HexinOCR:

	def __init__(self):
		filenames=(*[str(n) for n in range(10)],'dot','colon','add','min')
		dirname=os.path.dirname(__file__)
		self.__images=tuple([self.__to_binary_map(Image.open(dirname+'\\'+d+'.png')) for d in filenames])
		self.__digits=(*[str(n) for n in range(10)],'.',':','+','-')

	def recognize(self,im):
		if not isinstance(im,(Image.Image,ImageFile.ImageFile)):
			raise TypeError('Param <im> is not an image')
		text_lst=[]
		bm=self.__to_binary_map(im)
		w,h=self.__get_binary_map_size(bm)
		y=0
		while y<h:
			for x in range(w):
				if bm[y][x]!=0:
					text,line_h=self.__recognize_line(bm,y)
					if text!='':
						y+=line_h
						text_lst.append(text)
					break
			y+=1
		return text_lst

	def __recognize_line(self,bm,start_y):
		w,h=self.__get_binary_map_size(bm)
		text=''
		line_h=0
		x=0
		while x<w:
			for i in range(len(self.__digits)):
				sub=self.__images[i]
				if self.__has_sub_image(bm,x,start_y,sub):
					text+=self.__digits[i]
					sw,sh=self.__get_binary_map_size(sub)
					line_h=max(line_h,sh)
					x+=sw
					break
			x+=1
		return text,line_h

	def __has_sub_image(self,bm,start_x,start_y,sub):
		w,h=self.__get_binary_map_size(bm)
		sw,sh=self.__get_binary_map_size(sub)
		if start_x+sw>w or start_y+sh>h:
			return False
		for y in range(sh):
			if sub[y]!=bm[start_y+y][start_x:start_x+sw]:
				return False
		return True

	def __to_binary_map(self,im):
		w,h=im.size
		bm=[[0]*w for i in range(h)]
		raw=im.getdata()
		for y in range(h):
			for x in range(w):
				p=raw[y*w+x][0:3]
				bm[y][x]=(0 if p==(0,0,0) else 1)
		return bm

	def __get_binary_map_size(self,bm):
		return len(bm[0]),len(bm)